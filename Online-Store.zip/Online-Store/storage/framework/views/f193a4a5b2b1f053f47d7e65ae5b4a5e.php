
<?php $__env->startSection('product_edit'); ?>
<form action="<?php echo e(url('/product-update',$value->id)); ?>" method="POST" enctype="multipart/form-data" style="margin-left: 100px;">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?> 
    <h1>Update Product</h1>

    <div class="form-group">
        <label for="name">Name:</label>
        <input type="text" class="form-control" value="<?php echo e($value->name); ?>" name="name">
    </div>
  
    <div class="form-group">
        <label for="category">Category:</label>
        <select name="category" id="category" class="form-control">
            <option value="IT Services" <?php echo e($value->category == 'IT Services' ? 'selected' : ''); ?>>IT Services</option>
            <option value="Garments" <?php echo e($value->category == 'Garments' ? 'selected' : ''); ?>>Garments</option>
            <option value="Beauty Product" <?php echo e($value->category == 'Beauty Product' ? 'selected' : ''); ?>>Beauty Product</option>
            <option value="Book" <?php echo e($value->category == 'Book' ? 'selected' : ''); ?>>Book</option>
            <option value="Facial" <?php echo e($value->category == 'Facial' ? 'selected' : ''); ?>>Facial</option>
            <option value="Cosmetics" <?php echo e($value->category == 'Cosmetics' ? 'selected' : ''); ?>>Cosmetics</option>
            <option value="Bike" <?php echo e($value->category == 'Bike' ? 'selected' : ''); ?>>Bike</option>
        </select>
    </div>

    <div class="form-group">
        <label for="price">Price:</label>
        <input type="number" class="form-control" name="price" value="<?php echo e($value->price); ?>">
    </div>

    <div class="form-group">
        <label for="description">Description:</label>
        <textarea class="form-control" name="description" rows="4"><?php echo e($value->description); ?></textarea>
    </div>

    <div class="form-group">
        <label for="image">Image:</label>
        <input type="file" class="form-control" name="image" accept="image/*">
    </div>

    <div class="form-group">
        <label for="status">Status:</label>
        <select class="form-control" name="status" required>
            <option value="active" <?php echo e($value->status == 'active' ? 'selected' : ''); ?>>Active</option>
            <option value="inactive" <?php echo e($value->status == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
        </select>  
    </div>
  
    <button type="submit" class="btn btn-info">Update Product</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Online-Store\resources\views/backend/page/product_edit.blade.php ENDPATH**/ ?>